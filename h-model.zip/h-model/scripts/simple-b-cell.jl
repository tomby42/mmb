include("h-model.jl")

cfg = Dict(
    :size => (100, 100),
    :torus => (true, true),
    :seed => 1234,

    :sim => nothing,

    :vaxes_rule_steps => 10,

    :vaxes => @d(
        :t => @d(:D => 0.01,
                  :d => 0.0001,
                  :rd => 0.00001,
                  :show => true,
                  :init => (:, :, 0.1)
                 ),
        :e => @d(:D => 0.02,
                  :d => 0.001,
                  :rd => 0.00001,
                  :show => true,
                 ),
        :te => @d(:D => 0,
                  :d => 0.001,
                  :rd => 0.0001)
    ),

    :reactions => [
        @d(
            :react => [(1, :t), (1, :e)],
            :prod => [(1, :te)],
            :k => 0.001,
            :w => 1.0,
            :r_absorb => true,
        )
    ],

    :cells => [
      @d(
        :receptors => @d(:e => 0.05),
        :state => @d(:cum_state => :e, :cum_state_weight => 1.0, :resting_time => 0),
        :init_pos => (50,50)
      )
    ],

    :rule_graph => @d(
        :min_weight => 0.0,
        :resting_time => 1,
        :zg => @d(
            :e => [(:e, :prod_r, 0.001), (:e, :prod_v, 1),
                   (:e, :adhesion, 100), (:e, :volume, 50, 50), (:e, :perimeter, 2, 85),
                   (:t, :move, 12000), (:e, :activity, 200, 30)],
            :t => [(:t, :adhesion, 100), (:t, :volume, 50, 50), (:t, :perimeter, 2, 45)],
            :te => []
        ),
        :cpm => @d(
            :T => 20,
            :other_adhesion => 20,
        )
    ),

    :runtime => @d()
)

sim_desc = init_sim(cfg)

simulate(sim_desc, num_of_steps = 1000)
