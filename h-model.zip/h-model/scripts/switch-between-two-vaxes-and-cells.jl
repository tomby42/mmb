include("h-model.jl")

cfg = Dict(
    :size => (100, 100),
    :torus => (true, true),
    :seed => 1234,

    :sim => nothing,

    :vaxes_rule_steps => 10,

    :vaxes => @d(
        :t => @d(:D => 0.01,
                 :d => 0.00001,
                 :rd => 0.00001,
                 :show => true,
                 :init => (1:10, 1:10, 1)
        ),
        :tt => @d(:D => 0.05,
                  :d => 0.000001,
                  :rd => 0.00001,
                  :show => true,
                  :init => (60:69, 60:69, 2)
        ),
        :e => @d(:D => 0,
                  :d => 0.001,
                  :rd => 0.000001,
                 ),
        :e0 => @d(:D => 0,
                  :d => 0.00001,
                  :rd => 0.000001,
        ),
        :ee => @d(:D => 0,
                  :d => 0.001,
                  :rd => 0.00001,
        ),
        :eee => @d(:D => 0,
                   :d => 0.001,
                   :rd => 0.00001,
        ),
        :s1 => @d(:D => 0,
                 :d => 0.001,
                 :rd => 0.00001,
        ),
        :s2 => @d(:D => 0,
                  :d => 0.001,
                  :rd => 0.00001,
        ),
        :te => @d(:D => 0,
                  :d => 0.001,
                  :rd => 0.0001)
    ),

    :reactions => [
        @d(
            :react => [(1, :t), (1, :e)],
            :prod => [(1, :te)],
            :k => 0.001,
            :w => 1.0,
            :r_absorb => true,
        ),
       @d(
           :react => [(1, :t), (1, :e0)],
           :prod => [(1, :te)],
           :k => 0.001,
           :w => 1.0,
           :r_absorb => true,
        ),
        @d(
            :react => [(1, :t), (1, :eee)],
            :prod => [(1, :te)],
            :k => 0.001,
            :w => 1.0,
            :r_absorb => true,
        ),
        @d(
            :react => [(1, :tt), (1, :ee)],
            :prod => [(1, :te)],
            :k => 0.001,
            :w => 1.0, # 10000000.0,
            :r_absorb => true,
        ),
        @d(
           :react => [(1, :t), (1, :ee)],
           :prod => [(1, :te)],
           :k => 0.001,
           :w => 1.0,
           :r_absorb => true,
        ),
        @d(
            :react => [(1, :s1), (1, :s2)],
            :prod => [(1, :te)],
            :k => 0.001,
            :w => 10.0,
            :r_absorb => false,
       )
    ],

    :cells => [
      @d(
        :receptors => @d(:e0 => 1),
        :state => @d(:cum_state => :e0, :cum_state_weight => 1.0, :resting_time => 300),
        :init_pos => (50,50)
      ),
      @d(
          :receptors => @d(:s2 => 1),
          :state => @d(:cum_state => :s1, :cum_state_weight => 1.0, :resting_time => 0),
          :init_pos => (65,65)
      )
    ],

    :rule_graph => @d(
        :min_weight => 0.0,
        :resting_time => 1,
        :zg => @d(
            :e0 => [(:e, :prod_r, 0.001),
                    (:e0, :adhesion, 100), (:e0, :volume, 50, 50), (:e0, :perimeter, 2, 85),
                    (:t, :move, 12000), (:e0, :activity, 200, 30)],
            :e => [(:ee, :prod_r, 0.01),
                   (:e, :adhesion, 100), (:e, :volume, 50, 50), (:e, :perimeter, 2, 85),
                   (:t, :move, 12000), (:e, :activity, 200, 30)],
            :ee => [(:ee, :prod_r, 0.001), (:s1, :prod_r, 0.02),
                    (:ee, :adhesion, 100), (:ee, :volume, 50, 50), (:ee, :perimeter, 2, 85),
                    (:tt, :move, 15000), (:ee, :activity, 200, 50)],
            :s1 => [(:tt, :prod_v, 0.02),
                    (:s1, :adhesion, 100), (:s1, :volume, 50, 50), (:s1, :perimeter, 2, 85),
                    (:tt, :move, 12000), (:s1, :activity, 200, 30)],
            :s2 => [(:eee, :prod_r, 0.0001), (:eee, :prod_v, 0.0001),
                    (:s2, :adhesion, 100), (:s2, :volume, 50, 50), (:s2, :perimeter, 2, 85),
                    (:t, :move, 15000), (:s2, :activity, 200, 30)],
            :eee => [(:eee, :prod_r, 0.0001), (:eee, :prod_v, 0.0001),
                     (:eee, :adhesion, 100), (:eee, :volume, 50, 50), (:eee, :perimeter, 2, 85),
                     (:t, :move, 12000), (:eee, :activity, 200, 30)],
            :t => [(:t, :adhesion, 100), (:t, :volume, 50, 50), (:t, :perimeter, 2, 45)],
            :tt => [(:tt, :adhesion, 100), (:tt, :volume, 50, 50), (:tt, :perimeter, 2, 45)],
            :te => [(:te, :adhesion, 100), (:te, :volume, 50, 50), (:te, :perimeter, 2, 45)]
        ),
        :cpm => @d(
            :T => 20,
            :other_adhesion => 20,
        )
    ),

    :runtime => @d()
)

sim_desc = init_sim(cfg)

simulate(sim_desc, num_of_steps = 100)
